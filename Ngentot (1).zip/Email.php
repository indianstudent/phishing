<?php
$emailku = 'snsv.spamer@hotmail.com';
?>