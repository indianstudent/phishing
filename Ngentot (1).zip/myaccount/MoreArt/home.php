<?php include('../../blocker.php');?>
<?php include('../../detect.php'); ?>
<?php include('../form/info.php'); ?>
<?php include('footer.php'); ?>